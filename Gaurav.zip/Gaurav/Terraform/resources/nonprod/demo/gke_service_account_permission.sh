gcloud projects add-iam-policy-binding $2 \
 --member="serviceAccount:service-$1@container-engine-robot.iam.gserviceaccount.com" \
 --role="roles/compute.networkUser"

gcloud projects add-iam-policy-binding $2 \
 --member="serviceAccount:service-$1@container-engine-robot.iam.gserviceaccount.com" \
 --role="roles/container.hostServiceAgentUser"

gcloud projects add-iam-policy-binding $2 \
 --member="serviceAccount:service-$1@container-engine-robot.iam.gserviceaccount.com" \
 --role="roles/compute.securityAdmin"

gcloud projects add-iam-policy-binding $2 \
 --member="serviceAccount:$1@cloudservices.gserviceaccount.com" \
 --role="roles/compute.networkUser"
