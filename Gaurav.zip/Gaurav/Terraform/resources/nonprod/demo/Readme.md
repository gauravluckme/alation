# 

## Roles needed by Service Account
* (Editor) 
* App Engine Creator
* Cloud Datastore Owner
* Service Usage Admin
* Bigtable Admin
* Bigquery Admin
* Dataflow Admin
* Cloud IoT Admin
* Pub/Sub Admin
* roles/compute.viewer
* roles/compute.securityAdmin (only required if add_cluster_firewall_rules is set to true)
* roles/container.clusterAdmin
* roles/container.developer
* roles/iam.serviceAccountAdmin
* roles/iam.serviceAccountUser
* roles/resourcemanager.projectIamAdmin (only required if service_account is set to create)


## APIs need to be enabled
* Cloud Resource Manager API 
* Service Usage API
* Dataflow API
* Cloud IoT API
* Pub/Sub API
* BigTable Admin API
* Compute Engine API - compute.googleapis.com
* Kubernetes Engine API - container.googleapis.com


Change project ID in providers.tf and variables.tf files


## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| project\_id | The project ID to manage the Pub/Sub resources | `string` | n/a | yes |
| name | The name for the Pub/Sub topic and IoT name | `string` | n/a | yes |
| region | A region in which the Pub/Sub topic and IoT registry will be created. | `string` | us-central1 | no |

## Outputs

| Name | Description |
|------|-------------|
| project\_id | The project ID |

## Steps to execute terraform script
```
   cd resources/nonprod

   # Terraform initialization
   terraform init

   # Validate text plan file, tf_txt_plan.txt
   terraform plan -var-file=../../environments/nonprod/dev.tfvars -out=tf_bin_plan.bin -no-color > tf_txt_plan.txt

   # If valid, execute binary file, tf_bin_plan.bin
   terraform apply -auto-approve tf_bin_plan.bin
```