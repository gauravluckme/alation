#!/bin/bash

sed -i '/#PubkeyAuthentication yes/c\PubkeyAuthentication yes' /etc/ssh/sshd_config
sudo groupadd looker
sudo useradd -m  -g looker  looker
mkdir /home/looker/.ssh
chmod 700 /home/looker/.ssh
chown looker:looker /home/looker/.ssh
gsutil cp gs://looker-public-key/download-prod /home/looker/.ssh/authorized_keys
chmod 600 /home/looker/.ssh/authorized_keys
chown looker:looker /home/looker/.ssh/authorized_keys