## Providers

| Name | Version |
|------|---------|
| google | n/a |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:-----:|
| container\_spec\_gcs\_path | The GCS path to the Dataflow flex template. | `string` | n/a | yes |
| name | A unique name for the resource, required by Dataflow. | `string` | n/a | yes |
| on\_delete | One of "drain" or "cancel". Specifies behavior of deletion during terraform destroy. | `string` | `"cancel"` | no |
| parameters | Key/Value pairs to be passed to the Dataflow job (as used in the template). | `map(string)` | `{}` | no |
| project_id | The project in which the resource belongs. If it is not provided, the provider project is used. | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| job\_id | the unique ID of Dataflow Job |
| state | The current state of the resources in Dataflow job |

