#!/bin/sh

echo "ROLLBACK STARTED FOR VERSIONS $@"

rollbackVersions=$(echo $@)

for script in ${rollbackVersions};
do
    echo bash ./rollback/script_$(printf "%04d" ${script})_*.sh
    if [[ $? == 1 ]];
        then
            echo "The rollback script has some errors"
            exit 1
    fi
done
