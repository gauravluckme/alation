#!/bin/sh

echo "CREATING NEW VERSION"

GetLatestVersion () {
    filename=`ls -t ./versions/script*.sh | head -1`
    echo $filename
}

ExtractNumber () {
    number=$(echo $1 | tr -dc '0-9')
    echo $number | bc
}

IncrementVersion () {
    newVersion=$(($1 + 1))
    echo $(printf "%04d" $newVersion)
}

CreateNewVersion () {
    desc="${2// /_}"
    cat <<EOF >./versions/script_$1_$desc.sh
#!/bin/sh

echo "Running Version $1"
echo "<WRITE VERSION DESCRIPTION HERE>"

# WRITE CODE HERE

EOF

echo "./versions/script_$1_$desc.sh"
}

versionRaw=$(GetLatestVersion)
versionFinal=$(ExtractNumber $versionRaw)
versionNew=$(IncrementVersion $versionFinal)
versionStatus=$(CreateNewVersion $versionNew "$1")

echo "NEW VERSION $versionStatus Created"