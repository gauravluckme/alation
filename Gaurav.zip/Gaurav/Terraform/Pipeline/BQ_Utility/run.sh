#!/bin/sh

echo "APPLYING NEW VERSIONS STARTING FROM $1"

GetLatestVersion () {
    filename=`ls ./versions/script*.sh | tail -1`
    echo ${filename}
}

ExtractNumber () {
    number=$(echo $1 | tr -dc '0-9')
    echo ${number} | bc
}

ExecuteMigrationsScripts () {
    for ((i=$1;i<=$2;i++));
    do
        bash ./versions/script_$(printf "%04d" $i)_*.sh
        if [[ $? == 1 ]];
        then
            echo $i > latest.num
            exit 1
        fi
    done
}

versionRaw=$(GetLatestVersion)
versionFinal=$(ExtractNumber $versionRaw)
ExecuteMigrationsScripts $1 $versionFinal

echo $(($versionFinal+1)) > latest.num