# BQ Migrations Script

Create new Version

```bash
bash create.sh "description about the version"
```
Notes:
* Avoid giving special characters in the description.
* MaKe the description concise because it will be the name of the file
* Make sure yoy write the description inside the file as well. Make this more descriptive
* You can write any shell script inside the file. All gcloud utility commands are supported eg: gcloud, bq, gsutil

Run the migration

```bash
bash run.sh 4
```

Here 4 denotes that the utility will run all versions starting from 4 till the end