#!/bin/sh

echo "Running Version 0003"
echo "<UPDATION OF ACTIVE POWER IN fact_asset_payload 3 JHANSI MW>"

# WRITE CODE HERE
query="-- select * FROM
   update
\`noc-${ENV}-service-adani101.adn_ic_noc_${ENV}_industrial_data_platform.fact_asset_payload\`
 set value=value /1000000
  -- inner join
  --  asset
  -- ON fact.asset_id = asset.id
  -- Inner join
  --  ON
  -- fact.tag_id = tag.id
WHERE
-- date(ts)='2021-01-17'
  DATE(ts) BETWEEN '2018-01-01'   AND '2020-10-31'
  AND asset_id IN ( 
  (SELECT  id FROM    adn_ic_noc_${ENV}_asset_management.dim_asset  
--   WHERE    asset_category in 
--                  ( 'OUTGOINGS','INTERNAL_METERING_UNITS','CENTRAL_INVERTERS','STRING_INVERTERS','HIGH_TENSION_PANEL','LOW_TENSION_PANEL') 
--                  and name like '%OG%' 
-- and  name not like '%INV%' 
-- and name  like '%PANEL%' 
-- and name not like '%HT%'
)
)
  AND tag_id IN (  SELECT   id  FROM    adn_ic_noc_${ENV}_asset_management.dim_tag  WHERE    rnoc_tag_name IN ('ACTIVE_POWER') 
--   and source_id like '%GHANI%' 
  and source_id like '%JHANSI%' 
  and unit like 'MW'
  )
  and (metric like '%ACTIVE_POWER average%' or metric like 'ACTIVE_POWER')
--     and quality is null
-- and value >10000
-- 360375757 

-- and quality =192
--   AND value IS NULL
-- ORDER BY ts  "
echo "$query"
bq query --project_id="noc-${ENV}-service-adani101" --use_legacy_sql=false "$query"