import base64
import logging
import os
import json
from utils import pipeline_trigger 
from utils import cr_status
from utils import secret

env = os.environ.get('ENVIRONMENT')

def trigger_notification(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print("Payload Data")
    print(pubsub_message)
    process_notification(json.loads(pubsub_message))

def process_notification(scheduler_data):
    ## Cloud Run terraform details dictionary
    terraform_regions = {"use1": "us-east1", "usc1": "us-central1", "usw1": "us-west1"}    
    terraform_modules = {"preprocess": "pipeline_preprocess", "upload": "pipeline_upload", "dmparser": "pipeline_dmparser", "inference": "pipeline_inference"}
    
    ## Getting values from json
    project_id = scheduler_data['incident']['resource']['labels']['project_id']
    print("The project name is : " + project_id)
    displayName = scheduler_data['incident']['metric']['displayName']

    ## Extracting Cloud Run name from the payload
    split_displayName = displayName.split("/")
    job_id = [item for item in split_displayName if item.startswith("kdp")][0].replace("metric","cr").split("-")
    split_job_id = [item for item in job_id if item not in ("healthcheck")]
    cloud_run_name = '-'.join(split_job_id)
    region_name =  [item for item in split_job_id if item.startswith("us")][0]
    region = terraform_regions[[item for item in split_job_id if item.startswith("us")][0]]
    
    ## Get the module name for the resource
    nextItem = split_job_id.index(region_name)
    pipeline_name = split_job_id[nextItem+1]

    ## Get Authentication key value from Secret Manager
    authKey = secret.secret_key(project_id,env)

    ## Running the pipeline
    status = cr_status.cr_service_status(region_name,project_id,cloud_run_name)

    if status['Ready'] == 'Unknown' and status['ConfigurationsReady'] == "Unknown" and status['RoutesReady'] == 'Unknown' and "Deletion" in status['message']:
        print('Pipeline is already running and deletion is in progress')
        return()
    elif status['Ready'] == 'Unknown' and status['ConfigurationsReady'] == "Unknown" and status['RoutesReady'] == 'Unknown' and "Deploying" in status['message']:
        print('Pipeline is already running and deployment is in progress')
        return()
    elif status['Ready'] == 'True' and status['ConfigurationsReady'] == "True" and status['RoutesReady'] == 'True':
        print('Pipeline is already running, and the service is serving the requests')
        return()
    else:
        print(cloud_run_name, region)
        print('DR Pipeline Triggered')
        pipeline_trigger.build(authKey, region, pipeline_name, cloud_run_name, project_id, env)