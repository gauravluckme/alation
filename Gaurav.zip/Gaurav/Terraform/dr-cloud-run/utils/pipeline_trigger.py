import requests
import json

def build(AUTHKEY, REGION, PIPELINE_NAME, CLOUD_RUN_NAME, PROJECT_ID, ENV):
    ## Azure Pipeline URL
    url = 'https://dev.azure.com/KCBU/Cloud%20Recognition/_apis/pipelines/455/runs?api-version=6.0-preview.1'

    ## API request payload
    payload = json.dumps({
    "resources": {
        "repositories": {
        "self": {
            "refName": "refs/heads/feature/dr-pipeline"
        }
        }
    },
    "variables": {
        "PIPELINE_NAME": {
        "value": PIPELINE_NAME
        },
        "REGION": {
        "value": REGION
        },
        "CLOUD_RUN_NAME": {
        "value": CLOUD_RUN_NAME
        },
        "PROJECT_ID": {
        "value": PROJECT_ID
        },
        "ENV": {
        "value": ENV
        }
    }
    })

    ## API request headers
    headers = {
    'Authorization': AUTHKEY,
    'Content-Type': 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)
    print(response.text)