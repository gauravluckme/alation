from google.cloud import secretmanager

def secret_key(project_id, env):
    ## Get Authentication key value from Secret Manager
    client = secretmanager.SecretManagerServiceClient()
    name = client.secret_version_path(project_id, "kdp-podrec-"+env+"-secret-g-pipeline-auth", "latest")
    response = client.access_secret_version(name=name)
    authKey = response.payload.data.decode("UTF-8")
    return(authKey)