import json
import google.auth
from google.auth.transport.requests import AuthorizedSession

def cr_service_status(region, project_id, service_name):
    ## Cloud Run deployed region
    available_regions = {"usc1": "us-central1", "use1": "us-east1", "usw1": "us-west1"}
    region_name = available_regions[region]
    url = "https://"+region_name+"-run.googleapis.com/apis/serving.knative.dev/v1/namespaces/"+project_id+"/services/"+service_name
    credentials, project = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
    token = AuthorizedSession(credentials)
    response = token.request("GET", url)
    res_status = json.loads(response.text)
    status = {'Ready': '', 'ConfigurationsReady': '', 'RoutesReady': '', 'message': ''}
    if response.status_code == 200:
        ## Fetching status type i.e. Ready, ConfigurationsReady and RoutesReady
        for item in res_status['status']['conditions']:
            status[item['type']] = item['status']
        
        ## Fetching Cloud Run current status message i.e. Deploying Revision. , Deletion in progress.
        if status['Ready'] == "Unknown":
            message = [item.get('message') for item in res_status['status']['conditions']][0]
        else:
            message = ""
        
        ## Add message to status dictionary
        status['message'] = message
    print(f"The API is reponse is :- {response.status_code}")
    print(status)
    return(status)