import os
import json
import time
import google.auth
from google.auth.transport.requests import AuthorizedSession
from requests import auth

env                 = os.environ.get('ENVIRONMENT')
mig_name            = os.environ.get('MIG_NAME')
region              = os.environ.get('REGION')
instance_template   = os.environ.get('INSTANCE_TEMPLATE')
new_mig_name        = os.environ.get('NEW_MIG_NAME')

def eh_status(self):
    ## Create resource in other region
    available_regions = {"us-central1": "us-east1", "us-east1": "us-central1"}
    new_region = available_regions[region]
    print("The new region is : " + new_region)

    ## Available environments and the project name for each
    project_names = {"dev": "pod-recognition-nonprod", "test": "kdp-podrec-nonprod-test", "uat": "kdp-podrec-nonprod-uat", "prod": "kdp-podrec-prod"}
    project_id = project_names[env]
    
    mig_url = "https://compute.googleapis.com/compute/v1/projects/"+project_id+"/regions/"+region+"/instanceGroupManagers/"+mig_name
    credentials, project = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
    token = AuthorizedSession(credentials)
    response = token.request("GET", mig_url)
    eh_res = json.loads(response.text)
    print("The EH managed instance group response")
    print(eh_res)
    if response.status_code == 200:
        print("EH working fine")
    else:
        print("EH not working, MIG need to be created")
        url = "https://compute.googleapis.com/compute/v1/projects/"+project_id+"/regions/"+new_region+"/instanceGroupManagers/"
        
        payload = json.dumps({
        "name": new_mig_name,
        "instanceTemplate": "projects/"+project_id+"/global/instanceTemplates/"+instance_template,
        "baseInstanceName": new_mig_name,
        "targetSize": 1
        })
        
        credentials, project = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
        token = AuthorizedSession(credentials)
        res_mig = token.request("POST", url, data=payload)
        res_status_mig = json.loads(res_mig.text)
        print(res_status_mig)

        ## Check current status of new mig
        mig_url = "https://compute.googleapis.com/compute/v1/projects/"+project_id+"/regions/"+new_region+"/instanceGroupManagers/"+new_mig_name
        
        while True:
            print("Sleep for 10s")
            time.sleep(10)
            credentials, project = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
            token = AuthorizedSession(credentials)
            response = token.request("GET", mig_url)
            print(response)
            if response.status_code == 200:
                res_status = json.loads(response.text)
                current_status = res_status['status']['isStable']
                print("The current status is : ")
                print(current_status)
                if current_status == True:
                    break

        url = "https://www.googleapis.com/compute/beta/projects/"+project_id+"/regions/"+new_region+"/autoscalers"
        
        payload = json.dumps({
        "name": new_mig_name,
        "target": "projects/"+project_id+"/regions/"+new_region+"/instanceGroupManagers/"+new_mig_name,
        "region": new_region,
        "kind": "compute#autoscaler",
        "autoscalingPolicy": {
            "cpuUtilization": {
            "utilizationTarget": 0.6
            },
            "mode": "ON",
            "coolDownPeriodSec": 60,
            "minNumReplicas": 1,
            "maxNumReplicas": 1
        }
        })

        credentials, project = google.auth.default(scopes=['https://www.googleapis.com/auth/cloud-platform'])
        token = AuthorizedSession(credentials)
        res_asg = token.request("POST", url, data=payload)
        res_status_asg = json.loads(res_asg.text)
        print(res_status_asg)
        print("The MIG has been created")
    return "OK"