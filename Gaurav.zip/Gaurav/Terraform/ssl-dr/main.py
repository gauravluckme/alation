import os
from datetime import date,datetime
from googleapiclient import discovery
from oauth2client.client import GoogleCredentials

# Project ID for this request.
PROJECT_ID = os.environ.get('PROJECT_ID', 'PROJECT_ID variable is not set.')

def ssl_certificate_loadbalancer_alert(): 
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build('compute', 'v1', credentials=credentials, cache_discovery=False)

    request = service.sslCertificates().list(project=PROJECT_ID)

    while request is not None:
        response = request.execute()

        for ssl_certificate in response['items']:
            if ssl_certificate['type'] == 'SELF_MANAGED' :
                print("-----------------The SSL/TLS certificate name for Load Balancer----------------\n")
                print(ssl_certificate['name'])
                ssl_certificate_name = ssl_certificate['name']
                renew_date_str = ssl_certificate['expireTime'].split('T')[0]
                renew_date = datetime.strptime(renew_date_str,"%Y-%m-%d").date()
                print(f"The renew date for {ssl_certificate_name} is : {renew_date}")

                today = date.today()

                renew_days_left = (renew_date - today).days
                print(f"The SSL/TLS renew days left is {renew_days_left} days")

                if (int(renew_days_left) < 15):
                    print(f"The SSL/TLS certificate for Load Balancer need to be renewed for project - {PROJECT_ID} \n")
                else:
                    print(f"The SSL/TLS certificate for Load Balancer is valid for next {renew_days_left} days for project - {PROJECT_ID} \n")
                
        request = service.sslCertificates().list_next(previous_request=request, previous_response=response)
    return "OK"   

def ssl_certificate_appengine_alert(): 
    credentials = GoogleCredentials.get_application_default()
    service = discovery.build('appengine', 'v1', credentials=credentials, cache_discovery=False)
    request = service.apps().authorizedCertificates().list(appsId=PROJECT_ID)
    
    while request is not None:
        response = request.execute()

        for ssl_certificate in response['certificates']:
            ssl_certificate_name = ssl_certificate['displayName']
            if ( ssl_certificate_name != "managed_certificate" ):
                print("-----------------The SSL/TLS certificate name for App Engine----------------\n")
                renew_date_str = ssl_certificate['expireTime'].split('T')[0]
                renew_date = datetime.strptime(renew_date_str,"%Y-%m-%d").date()

                print(f"The renew date for {ssl_certificate_name} is : {renew_date}")

                today = date.today()
                renew_days_left = (renew_date - today).days
                print(f"The SSL/TLS renew days left is {renew_days_left} days")
                if (int(renew_days_left) < 15):
                    print(f"The SSL/TLS certificate for AppEngine need to be renewed for project - {PROJECT_ID} \n")
                else:
                    print(f"The SSL/TLS certificate for AppEngine is valid for next {renew_days_left} days for project - {PROJECT_ID} \n")
            
            
        request = service.apps().authorizedCertificates().list_next(previous_request=request, previous_response=response)
   
    return "OK"    

def findRenewDate(self):
    ssl_certificate_loadbalancer_alert()
    ssl_certificate_appengine_alert()

if __name__ == "__main__":
    findRenewDate()